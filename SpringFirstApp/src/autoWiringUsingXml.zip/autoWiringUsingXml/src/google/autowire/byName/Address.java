package google.autowire.byName;

public class Address {
	
	
	private int shome;
	private String sstreet;
	
	public int getShome() {
		return shome;
	}
	public void setShome(int shome) {
		this.shome = shome;
	}
	public String getSstreet() {
		return sstreet;
	}
	public void setSstreet(String sstreet) {
		this.sstreet = sstreet;
	}
	

}
